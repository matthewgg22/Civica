// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "VoteNow",
    defaultLocalization: "en",
    platforms: [
        .iOS("17.0")
    ],
    products: [
        .iOSApplication(
            name: "VoteNow",
            targets: ["AppModule"],
            bundleIdentifier: "com.matthewgreergentis.votenow",
            teamIdentifier: "",
            displayVersion: "1.0",
            bundleVersion: "1",
            appIcon: .asset("AppIcon"),
            accentColor: .asset("AccentColor"),
            supportedDeviceFamilies: [
                .phone,
                .pad
            ],
            supportedInterfaceOrientations: [
                .portrait,
                .landscapeRight,
                .landscapeLeft
            ]
        )
    ],
    targets: [
        .executableTarget(
            name: "AppModule",
            path: "WeVote Information Page",
            exclude: [
                "Preview Content",
                ".DS_Store",
                "Assets.xcassets/.DS_Store",
                "Views/.DS_Store"
            ],
            resources: [
                .process("Assets.xcassets"),
                .process("Models/NYCRepresentativesRoster.json"),
                .process("Views/NYCReps.json")
            ]
        )
    ]
)
